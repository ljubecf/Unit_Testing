package unittesting.parcijalni;

public class CarRepository {

	// TODO: implement function in another sprint
	public Car findByChassisNumber(String chassisNumber) {
		return null;
	}
}
