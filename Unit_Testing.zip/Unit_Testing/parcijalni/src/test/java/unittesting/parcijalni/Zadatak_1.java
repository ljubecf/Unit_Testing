package unittesting.parcijalni;

import static org.testng.Assert.assertEquals;

import org.mockito.Mockito;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Zadatak_1 {

	TehnicalInspection tehnicalI;
	CarRepository mockedCarRepo;
	Car car;

	@BeforeMethod
	public void setUp() {
		tehnicalI = new TehnicalInspection();
		mockedCarRepo = Mockito.mock(CarRepository.class);

		tehnicalI.setCarRepository(mockedCarRepo);

	}

	@Test(expectedExceptions = IllegalArgumentException.class)
	public void testExeption() throws IllegalArgumentException, NotFound {

		Mockito.when(mockedCarRepo.findByChassisNumber("1234567891234569")).thenReturn(null);
		tehnicalI.needCarService("1234567891234569");

	}

	@Test
	public void test1() throws NotFound {

		Mockito.when(mockedCarRepo.findByChassisNumber("12345678912345698")).thenReturn(new Car(75202));

		String actual = tehnicalI.needCarService("12345678912345698");

		assertEquals(actual, "Mali servis");

	}

	@Test
	public void test2() throws NotFound {

		Mockito.when(mockedCarRepo.findByChassisNumber("12345678912345698")).thenReturn(new Car(1500000));
		tehnicalI.needCarService("12345678912345698");
		String actual = tehnicalI.needCarService("12345678912345698");

		assertEquals(actual, "Veliki servis");

	}

}
