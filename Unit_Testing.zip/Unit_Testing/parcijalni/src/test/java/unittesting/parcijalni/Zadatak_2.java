package unittesting.parcijalni;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Zadatak_2 {

	TehnicalInspection technicalInspection;
							
	// dataProviderClass = TestParamDataProvider.class

	@BeforeMethod
	public void setUp() {
		technicalInspection = new TehnicalInspection();
	}

	// @Test(dataProvider = "providerData", dataProviderClass =
	// KlasaDataProvider.class)

	// nisam uspeo da pronadjem resenje ovog sa data klass zasto nece...
	@Test(dataProvider = "providerData")
	public void carAgeCategory(int productionYear, String ageCategory) {

		technicalInspection.carAgeCategory(productionYear);
		String ocekivano = ageCategory;

		String actual = technicalInspection.carAgeCategory(productionYear);

		assertEquals(actual, ocekivano);
	}

	@DataProvider(name = "providerData")
	public Object[][] dataprovider() {

		return new Object[][] {

				{ 2022, "Not classified" }, { 3030, "Not classified" }, { 1923, "Vintage Car" },
				{ 1929, "Vintage Car" }, { 1922, "Vintage Car" }, { 1968, "Antique Car" }, { 1989, "Classic Car" },
				{ 2000, "Modern Car" }, { 2021, "Modern Car" }, };
	}

}
