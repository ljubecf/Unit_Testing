package unittesting.parcijalni;

import org.testng.annotations.DataProvider;

public class KlasaDataProvider {

	@DataProvider(name = "providerData")
	public Object[][] dataprovider() {

		return new Object[][] {

				{ 3030, "Not classified" }, { 1923, "Vintage Car" }, { 1929, "Vintage Car" }, { 1922, "Vintage Car" },
				{ 1968, "Antique Car" }, { 1989, "Classic Car" }, { 2000, "Modern Car" }, { 2021, "Modern Car" }, };
	}

}
